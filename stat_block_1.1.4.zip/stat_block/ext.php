<?php
//HarveyWNvm // visit https://appunlockstoryplay.top/
namespace hrvy\stat_block;


class ext extends \phpbb\extension\base
{

	public function is_enableable()
	{
		$config = $this->container->get('config');
		return version_compare($config['version'], '3.3.11', '>=');
	}
}
